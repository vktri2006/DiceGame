﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Windows.Threading;

namespace WpfAppTest1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer dispatcherTimer;
        Random rnd = new Random();
        int intDice1 = 0;
        int intDice2 = 0;
        static int intCountRun = 0;

        public MainWindow()
        {
            InitializeComponent();

            LoadConfig();
        }


        /// <summary>
        /// Get random number from the provided range
        /// </summary>
        /// <param name="intLowerVal"></param>
        /// <param name="intUpperVal"></param>        
        /// <returns></returns>
        private int GetRnd(int intLowerVal, int intUpperVal)
        {
            return rnd.Next(intLowerVal, intUpperVal);
        }


        /// <summary>
        /// For each roll the function will generate the random value
        /// </summary>
        private void RollDice()
        {           
            string strImgPath = ConfigurationManager.AppSettings["ImgPath"].ToString() + @"\dice";
            intDice1 = GetRnd(1, 7);
            string strUrl = strImgPath + intDice1.ToString() + ".PNG";

            if (!System.IO.File.Exists(strUrl))
            {
                MessageBox.Show("The file does not exist at location [" + strUrl + "]. Please check App.config and update the setting. The program terminated!");
                System.Windows.Application.Current.Shutdown();
                return;
            }


            Uri fileUri1;
            Uri fileUri2;
            
            fileUri1 = new Uri(strUrl);
            ImgDice1.Source = new BitmapImage(fileUri1);
            System.Threading.Thread.Sleep(100);

            //Second dice
            intDice2 = GetRnd(1, 7);
            strUrl = strImgPath + intDice2.ToString() + ".PNG";
            fileUri2 = new Uri(strUrl);
            ImgDice2.Source = new BitmapImage(fileUri2);
            System.Threading.Thread.Sleep(100);

            
        }


        /// <summary>
        /// Save result to log file
        /// </summary>
        private void SaveToLog() 
        {
            System.IO.StreamWriter writer;
            string strLog = "";
            try { 

                strLog = ConfigurationManager.AppSettings["LogFile"].ToString();            
                writer = new System.IO.StreamWriter(strLog, true);
                writer.WriteLine("Roll at [" + System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + "] " + intDice1.ToString() + ":" + intDice2.ToString());
                writer.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        } 

        /// <summary>
        /// Handle button click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRoll_Click(object sender, RoutedEventArgs e)
        {

            dispatcherTimer = null;
            dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
            dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 500);
            dispatcherTimer.Start();

        }

        
        /// <summary>
        /// Reset settings to the controls
        /// </summary>
        private void LoadConfig()
        {
            txtNumOfRoll.Text = ConfigurationManager.AppSettings["NumberOfRolls"].ToString();
            txtLogFile.Text = ConfigurationManager.AppSettings["LogFile"].ToString();
            txtImgPath.Text = ConfigurationManager.AppSettings["ImgPath"].ToString();
        }

        /// <summary>
        /// Reload the app.config values to the screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            LoadConfig();
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            int intVal = 0;
            try
            {
                intVal = Int16.Parse(txtNumOfRoll.Text);
            }
            catch 
            {
                intVal = 5;
                txtNumOfRoll.Text = intVal.ToString();
            }

           
            if (intCountRun < intVal)
            {
                RollDice();
                SaveToLog();
                intCountRun++;
            }            
            else
            {
                intCountRun = 0;
                dispatcherTimer.Stop();

            }
                
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
       
        }
    }
}
